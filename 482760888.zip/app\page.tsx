/**
 * Página principal que integra os cards de sistemas com os recursos de acessibilidade
 */

import SystemCards from "@/system-cards"

export default function Home() {
  return <SystemCards />
}

